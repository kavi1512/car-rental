package com.example.WheelWise.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import  com.example.WheelWise.entities.User;
import com.example.WheelWise.services.UserService;
@RestController
public class forgotpasswordController {
    @Autowired
    UserService service;

    @RequestMapping("/User/{email}")
    public User getUserById(@PathVariable  String email ){
        return service.getUserById(email);
    }

    @PutMapping("User")
    public User updatepassword(@RequestBody User user){
        service.updatepassword(user);
        return user;
    }

}
