package com.example.WheelWise.Controller;

import com.example.WheelWise.entities.User;
import com.example.WheelWise.services.OTPService;
import com.example.WheelWise.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/otp")
public class OTPController {

    @Autowired
    private OTPService otpService;

    @Autowired
    private UserService userService;

    // Endpoint to send OTP to the user's email
    @PostMapping("/send")
    public Map<String, String> sendOTP(@RequestParam String email) {
        String message = otpService.generateAndSendOTP(email);

        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return response;
    }

    // Endpoint to validate OTP and update password
    @PostMapping("/validate")
    public Map<String, String> validateOTP(@RequestParam String email, @RequestParam String otp, @RequestParam String newPassword) {
        Map<String, String> response = new HashMap<>();

        boolean isValid = otpService.validateOTP(email, otp);

        if (isValid) {
            // OTP is valid, update the user's password
            User user = userService.getUserById(email);
            user.setPassword(newPassword); // You should hash the password here for security

            userService.updatepassword(user); // Save updated password
            response.put("message", "Password updated successfully");
        } else {
            response.put("message", "Invalid or expired OTP");
        }

        response.put("isValid", Boolean.toString(isValid));
        return response;
    }
}
