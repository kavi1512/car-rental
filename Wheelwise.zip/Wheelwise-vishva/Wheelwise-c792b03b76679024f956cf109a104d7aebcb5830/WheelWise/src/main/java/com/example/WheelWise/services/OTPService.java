package com.example.WheelWise.services;

import com.example.WheelWise.entities.OTP;
import com.example.WheelWise.repositories.OTPRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class OTPService {

    @Autowired
    private OTPRepository otpRepository;

    @Autowired
    private JavaMailSender mailSender;

    public String generateAndSendOTP(String email) {
        // Generate a 6-digit OTP
        String otp = String.format("%06d", new Random().nextInt(999999));

        // Save OTP to the database with expiry time
        OTP otpEntity = otpRepository.findByEmail(email).orElse(new OTP());
        otpEntity.setEmail(email);
        otpEntity.setOtp(otp);
        otpEntity.setExpiryTime(LocalDateTime.now().plusMinutes(5)); // OTP valid for 5 minutes
        otpRepository.save(otpEntity);

        // Send the OTP via email
        sendEmail(email, otp);

        return "OTP sent successfully to " + email;
    }

    private void sendEmail(String email, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your OTP Code");
        message.setText("Your OTP is: " + otp + ". It is valid for 5 minutes.");
        mailSender.send(message);
    }

    public boolean validateOTP(String email, String otp) {
        Optional<OTP> otpOptional = otpRepository.findByEmail(email);

        if (otpOptional.isEmpty()) {
            return false;
        }

        OTP otpEntity = otpOptional.get();

        // Check if OTP matches and is not expired
        if (otpEntity.getOtp().equals(otp) && otpEntity.getExpiryTime().isAfter(LocalDateTime.now())) {
            otpRepository.delete(otpEntity); // OTP should be used only once
            return true;
        }

        return false;
    }
}
