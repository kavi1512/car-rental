package com.example.WheelWise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WheelWiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(WheelWiseApplication.class, args);
	}

}
