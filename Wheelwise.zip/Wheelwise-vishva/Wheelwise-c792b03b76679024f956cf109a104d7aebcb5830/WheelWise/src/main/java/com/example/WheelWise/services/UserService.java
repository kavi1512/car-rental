package com.example.WheelWise.services;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.WheelWise.entities.User;
import com.example.WheelWise.repositories.UserRepository;
@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder(); // Initialize password encoder

	// Method to create a new user
	public User createUser(User user) {
		return userRepository.save(user);
	}

	// Method to retrieve a user by email
	public User getUserById(String email) {
		return userRepository.findByEmail(email).orElse(new User());
	}

	// Method to update password
	public User updatepassword(User user) {
		// Hash the new password before saving it
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		return userRepository.save(user);
	}
}