package com.example.WheelWise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WheelWiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
